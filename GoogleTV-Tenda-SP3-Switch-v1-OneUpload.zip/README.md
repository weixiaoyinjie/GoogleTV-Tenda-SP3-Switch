# Google TV · Tenda SP3 电视遥控开关 v1.0

这是根据上传的 `Watch8-Tenda-SP3-QuickSwitch-v1-OneUpload.zip` 改编的独立 **Google TV / Android TV** App。并非 Tenda 官方产品。

## 功能

- **首页横屏两张大卡片**：电灯、风扇，一屏显示真实开关状态及 IP。
- 使用 Google TV 遥控器上下左右方向键切换焦点，**OK** 开/关，**返回** 离开。
- 首次进入读取实际状态；需要时按「刷新两台设备状态」。
- 控制时先读取实际状态，再执行反向切换，之后再次读取确认，避免使用旧缓存导致反向误操作。
- **IP 设置**：自动扫描同网段设备（按 MAC 匹配），或通过 D-pad 数字键盘分别修改两台设备 IP。
- 默认启用 MAC 身份校验，可在设置中选择关闭，关闭存在误操作风险。
- 本地直连插座 **TCP 5000**、无云端账号、不需要手机或 Watch 8 在线，支持电视的有线 Ethernet 与 Wi-Fi。

## 内置原设备信息（来自上传的 Watch8 源码）

| 设备 | 默认 IP | 预期 MAC |
| --- | --- | --- |
| 电灯 | `192.168.0.30` | `D8:32:14:65:62:B8` |
| 风扇 | `192.168.0.31` | `D8:32:14:65:63:6C` |

电视会在**自己的**本地存储中保存 IP，不和手机或手表自动同步；如果设备 IP 已更改，在设置内重新扫描或修改。需电视与插座在互通的本地网络；如果使用访客网络、客户端隔离或跨 VLAN 阻断，将不能控制。扫描范围仅为电视当前地址的 /24 段。**不要将插座 TCP 5000 端口暴露到公网**，协议是 HTTP 明文。

## Google TV 适配细节

- 独立应用包名：`com.tenda.sp3quick.googletv`，不会覆盖手机/手表版。
- `android.software.leanback`、`LEANBACK_LAUNCHER`、`android.hardware.touchscreen` 不强制，含电视桌面 320×180 横幅与应用图标。
- 横屏、焦点描边、焦点放大、大字号；设置全程可遥控器操作，不依赖触屏或外接键盘。
- 仅在用户开启 App、点击刷新/开关、启动扫描时进行网络访问；不持续后台轮询。
- API 23+、Android SDK 35、Android Gradle Plugin 8.6.1、Gradle 8.7、JDK 17。

## 手机上传 ZIP → GitHub Actions 编译 APK

1. 创建 GitHub 仓库：`GoogleTV-Tenda-SP3-Switch`（建议 Private）。
2. 使用 GitHub `Add file → Upload files`，把 **`GoogleTV-Tenda-SP3-Switch-v1-OneUpload.zip` 原样上传到仓库根目录**，无需解压。
3. 在仓库点击 `Add file → Create new file`，文件名输入 **`.github/workflows/build-apk.yml`**。粘贴我同时提供的 **`GoogleTV_Tenda_SP3_GitHub_Build.yml`** 文件内容，Commit。
4. 点击 `Actions → Build Google TV SP3 APK → Run workflow`（或创建工作流后由 push 自动触发，须确保 ZIP 已在仓库根目录）。
5. 编译成功后下载 `GoogleTV-Tenda-SP3-Switch-APK` Artifact，解压得到 `app-debug.apk`，安装到 Google TV。

⚠️ GitHub 不会读取 ZIP 内部的隐藏 `.github/workflows/` 作为工作流；**必须**通过步骤 3 在仓库创建独立工作流文件。ZIP 内工作流只用于用户解压后自行构建。

## 电视安装方式

可以通过 Google TV 的文件传输工具把 APK 发送到电视，再打开文件管理器安装。电视可能要求在设置中对用于安装 APK 的文件管理器授权「安装未知应用」。

## 验证状态

已从用户上传源码复用设备控制逻辑、检查代码结构和打包文件；当前执行环境没有 Android SDK，**无法在本地完成真实编译**，也未在实际 Google TV / Tenda SP3 设备上连接测试。请用上面的 GitHub Actions 流程编译，并在真实电视上验证网络与方向键。
