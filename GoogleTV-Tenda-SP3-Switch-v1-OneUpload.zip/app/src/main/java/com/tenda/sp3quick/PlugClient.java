package com.tenda.sp3quick;

import android.net.Network;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Original Tenda Beli SP3 local HTTP protocol through selected TV LAN. */
final class PlugClient {
    private final String ip;
    private final Network network;
    PlugClient(String ip, Network network) { this.ip = ip; this.network = network; }

    JSONObject detail() throws Exception { return request("GET", "getDetail", null, 1100, 1200).getJSONObject("data"); }
    String mac() throws Exception { return detail().optString("mac", "").toUpperCase(); }

    void verify(String expectedMac) throws Exception {
        String reported = mac();
        String actual = reported.replace(":", "").replace("-", "");
        String wanted = expectedMac.replace(":", "").replace("-", "");
        if (actual.isEmpty() || !actual.equalsIgnoreCase(wanted)) {
            throw new IOException("MAC 不匹配：目标 " + expectedMac + "，实际 " + reported);
        }
    }

    int getState() throws Exception {
        JSONObject json = request("POST", "getSta", new byte[0], 1400, 1400);
        JSONObject data = json.optJSONObject("data");
        if (data == null || !data.has("status")) throw new IOException("设备未返回开关状态");
        int state = data.getInt("status");
        if (state != 0 && state != 1) throw new IOException("异常状态：" + state);
        return state;
    }

    void setState(int state) throws Exception {
        JSONObject body = new JSONObject();
        body.put("status", state);
        JSONObject json = request("POST", "setSta", body.toString().getBytes(StandardCharsets.UTF_8), 1400, 1400);
        if (json.has("status") && json.getInt("status") != state) throw new IOException("开关反馈状态不一致");
    }

    static String getMacFast(String ip, Network network) throws Exception {
        JSONObject data = new PlugClient(ip, network).request("GET", "getDetail", null, 350, 600).optJSONObject("data");
        return data == null ? "" : data.optString("mac", "");
    }

    private JSONObject request(String method, String path, byte[] body, int connectMs, int readMs) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) network.openConnection(new URL("http://" + ip + ":5000/" + path));
            connection.setRequestMethod(method);
            connection.setConnectTimeout(connectMs);
            connection.setReadTimeout(readMs);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Connection", "close");
            if (body != null) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setFixedLengthStreamingMode(body.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(body); }
            }
            int code = connection.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code + " /" + path);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = connection.getInputStream()) {
                byte[] buf = new byte[1024];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    if (out.size() > 8192) throw new IOException("设备响应过大");
                }
            }
            JSONObject json = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
            if (json.optInt("resp_code", -999) != 0) {
                throw new IOException("设备拒绝命令：" + json.optInt("resp_code", -999));
            }
            return json;
        } catch (JSONException e) {
            throw new IOException("设备数据格式错误", e);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
