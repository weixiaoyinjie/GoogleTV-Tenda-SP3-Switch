package com.tenda.sp3quick;

import android.content.Context;
import android.net.Network;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One serial worker prevents conflicting network commands to SP3 plugs. */
final class Controller {
    interface Done { void finished(boolean success, String message); }
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();

    static void refresh(Context ctx, String device, Done callback) {
        Context app = ctx.getApplicationContext();
        WORKER.execute(() -> {
            try {
                Network wifi = NetworkRouter.local(app);
                PlugClient plug = new PlugClient(Devices.ip(app, device), wifi);
                if (Devices.verifyMac(app)) plug.verify(Devices.mac(device));
                int state = plug.getState();
                Devices.setError(app, device, "");
                Devices.setStatus(app, device, state);
                if (callback != null) callback.finished(true, Devices.name(device) + "状态已更新");
            } catch (Exception e) {
                fail(app, device, e);
                if (callback != null) callback.finished(false, errorMessage(e));
            }
        });
    }

    static void toggle(Context ctx, String device, Done callback) {
        Context app = ctx.getApplicationContext();
        Devices.setStatus(app, device, Devices.PENDING);
        WORKER.execute(() -> {
            try {
                Network wifi = NetworkRouter.local(app);
                PlugClient plug = new PlugClient(Devices.ip(app, device), wifi);
                if (Devices.verifyMac(app)) plug.verify(Devices.mac(device));
                int actual = plug.getState();
                int next = actual == 1 ? 0 : 1;
                plug.setState(next);
                int confirmed = plug.getState();
                if (confirmed != next) throw new IllegalStateException("设备未确认新状态，请刷新后重试");
                Devices.setError(app, device, "");
                Devices.setStatus(app, device, confirmed);
                if (callback != null) callback.finished(true, Devices.name(device) + (confirmed == 1 ? "已开启" : "已关闭"));
            } catch (Exception e) {
                fail(app, device, e);
                if (callback != null) callback.finished(false, errorMessage(e));
            }
        });
    }

    private static String errorMessage(Exception e) {
        String s = e.getMessage();
        return s == null || s.trim().isEmpty() ? "网络连接失败" : s;
    }
    private static void fail(Context app, String device, Exception e) {
        Devices.setError(app, device, errorMessage(e));
        Devices.setStatus(app, device, Devices.UNKNOWN);
    }
}
