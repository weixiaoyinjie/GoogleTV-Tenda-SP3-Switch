package com.tenda.sp3quick;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;

/** Uses the Google TV's local Wi-Fi OR wired Ethernet LAN, not an internet-only VPN. */
final class NetworkRouter {
    private NetworkRouter() { }

    static Network local(Context context) throws IOException {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) throw new IOException("无法读取电视网络信息");
        // Prefer the network the TV is actively using, if it is local Ethernet or Wi-Fi.
        Network active = cm.getActiveNetwork();
        if (valid(cm, active)) return active;
        for (Network network : cm.getAllNetworks()) {
            if (valid(cm, network)) return network;
        }
        throw new IOException("电视须连接可访问插座的家庭 Wi-Fi 或有线局域网");
    }

    private static boolean valid(ConnectivityManager cm, Network net) {
        if (net == null) return false;
        NetworkCapabilities c = cm.getNetworkCapabilities(net);
        return c != null && (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
                && localV4(cm.getLinkProperties(net)) != null;
    }

    static String prefix(Context context, Network network) throws IOException {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        LinkProperties properties = cm == null ? null : cm.getLinkProperties(network);
        Inet4Address address = localV4(properties);
        if (address == null) throw new IOException("电视没有可用的局域网 IPv4 地址");
        String text = address.getHostAddress();
        return text.substring(0, text.lastIndexOf('.') + 1);
    }

    private static Inet4Address localV4(LinkProperties properties) {
        if (properties == null) return null;
        for (LinkAddress link : properties.getLinkAddresses()) {
            InetAddress a = link.getAddress();
            if (a instanceof Inet4Address && a.isSiteLocalAddress()) return (Inet4Address) a;
        }
        return null;
    }
}
