package com.tenda.sp3quick;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Landscape, D-pad-first widgets: no phone touch gestures, external dependencies, or Compose. */
final class TvUi {
    static final int BG = Color.rgb(12, 18, 28);
    static final int PANEL = Color.rgb(29, 39, 55);
    static final int GREEN = Color.rgb(22, 99, 82);
    static final int RED = Color.rgb(83, 59, 69);
    static final int AMBER = Color.rgb(101, 72, 45);
    static final int WHITE = Color.rgb(243, 247, 252);
    static final int MUTED = Color.rgb(174, 190, 208);
    static final int FOCUS = Color.rgb(116, 226, 194);

    private TvUi() { }
    static int dp(Activity a, float v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }
    static LinearLayout page(Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        ScrollView scroll = new ScrollView(a);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout c = new LinearLayout(a);
        c.setPadding(dp(a, 58), dp(a, 30), dp(a, 58), dp(a, 28));
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        scroll.addView(c, new ScrollView.LayoutParams(-1, -2));
        a.setContentView(scroll);
        return c;
    }
    static TextView text(Activity a, String label, float size, int color, boolean bold) {
        TextView v = new TextView(a);
        v.setText(label);
        v.setTextColor(color);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    static GradientDrawable bg(Activity a, int color, int border) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(a, 20));
        if (border != Color.TRANSPARENT) d.setStroke(dp(a, 3), border);
        return d;
    }
    static void focusStyle(Activity a, View view, int baseColor) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[] { android.R.attr.state_focused }, bg(a, baseColor, FOCUS));
        states.addState(new int[] { android.R.attr.state_pressed }, bg(a, baseColor, FOCUS));
        states.addState(new int[] { }, bg(a, baseColor, Color.TRANSPARENT));
        view.setBackground(states);
        view.setFocusable(true);
        view.setClickable(true);
        view.setOnFocusChangeListener((v, focused) -> {
            v.animate().scaleX(focused ? 1.026f : 1f).scaleY(focused ? 1.026f : 1f).setDuration(120).start();
            v.setElevation(dp(a, focused ? 15 : 0));
        });
    }
    static Button button(Activity a, String label, int color, int height) {
        Button b = new Button(a);
        b.setText(label);
        b.setTextColor(WHITE);
        b.setTextSize(19);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(a, height));
        b.setMinimumHeight(dp(a, height));
        b.setPadding(dp(a, 14), dp(a, 7), dp(a, 14), dp(a, 7));
        // Avoid default platform button tint overriding the focused border.
        b.setBackgroundTintList((ColorStateList) null);
        focusStyle(a, b, color);
        return b;
    }
    static void add(LinearLayout parent, View child, Activity a, int heightDp, int bottomDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                heightDp <= 0 ? ViewGroup.LayoutParams.WRAP_CONTENT : dp(a, heightDp));
        p.bottomMargin = dp(a, bottomDp);
        parent.addView(child, p);
    }
}
