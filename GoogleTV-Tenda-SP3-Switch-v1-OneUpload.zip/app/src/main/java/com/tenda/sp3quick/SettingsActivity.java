package com.tenda.sp3quick;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** TV settings: fully controllable with direction keys and OK, no Switch touch widget. */
public final class SettingsActivity extends Activity {
    private Button lightButton, fanButton, verifyButton, scanButton;
    private TextView info;
    private boolean scanning;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = TvUi.page(this);
        TvUi.add(page, TvUi.text(this, "设备设置", 34, TvUi.WHITE, true), this, 53, 5);
        TvUi.add(page, TvUi.text(this, "遥控器方向键选择 · OK 修改 · 返回键回到开关", 17, TvUi.MUTED, false), this, 34, 15);

        LinearLayout columns = new LinearLayout(this);
        columns.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.rightMargin = TvUi.dp(this, 20);
        columns.addView(left, lp);
        columns.addView(right, new LinearLayout.LayoutParams(0, -2, 1));

        lightButton = TvUi.button(this, "", TvUi.PANEL, 85);
        fanButton = TvUi.button(this, "", TvUi.PANEL, 85);
        verifyButton = TvUi.button(this, "", TvUi.PANEL, 85);
        scanButton = TvUi.button(this, "自动扫描设备 IP", TvUi.GREEN, 85);
        TvUi.add(left, lightButton, this, 85, 14);
        TvUi.add(left, fanButton, this, 85, 0);
        TvUi.add(right, verifyButton, this, 85, 14);
        TvUi.add(right, scanButton, this, 85, 0);
        TvUi.add(page, columns, this, -1, 15);

        info = TvUi.text(this, "IP 仅保存在电视本机。局域网扫描范围：电视当前网段的 /24。", 16, TvUi.MUTED, false);
        TvUi.add(page, info, this, 52, 8);
        Button back = TvUi.button(this, "←  返回开关", TvUi.PANEL, 56);
        TvUi.add(page, back, this, 56, 0);
        back.setOnClickListener(v -> finish());

        lightButton.setOnClickListener(v -> edit(Devices.LIGHT));
        fanButton.setOnClickListener(v -> edit(Devices.FAN));
        verifyButton.setOnClickListener(v -> {
            boolean on = !Devices.verifyMac(this);
            Devices.setVerifyMac(this, on);
            Devices.resetState(this);
            update();
        });
        scanButton.setOnClickListener(v -> scan());

        lightButton.setId(View.generateViewId());
        fanButton.setId(View.generateViewId());
        verifyButton.setId(View.generateViewId());
        scanButton.setId(View.generateViewId());
        back.setId(View.generateViewId());
        lightButton.setNextFocusRightId(verifyButton.getId());
        verifyButton.setNextFocusLeftId(lightButton.getId());
        fanButton.setNextFocusRightId(scanButton.getId());
        scanButton.setNextFocusLeftId(fanButton.getId());
        lightButton.setNextFocusDownId(fanButton.getId());
        fanButton.setNextFocusUpId(lightButton.getId());
        verifyButton.setNextFocusDownId(scanButton.getId());
        scanButton.setNextFocusUpId(verifyButton.getId());
        fanButton.setNextFocusDownId(back.getId());
        scanButton.setNextFocusDownId(back.getId());
        back.setNextFocusUpId(fanButton.getId());
        update();
        lightButton.requestFocus();
    }
    @Override protected void onResume() {
        super.onResume();
        update();
    }
    private void update() {
        if (lightButton == null) return;
        lightButton.setText("电灯 IP   ·   点击修改\n" + Devices.ip(this, Devices.LIGHT));
        fanButton.setText("风扇 IP   ·   点击修改\n" + Devices.ip(this, Devices.FAN));
        verifyButton.setText("MAC 身份校验\n" + (Devices.verifyMac(this) ? "已开启（推荐）" : "已关闭（谨慎）"));
    }
    private void edit(String device) {
        startActivity(new Intent(this, IpEditActivity.class).putExtra(IpEditActivity.KEY_DEVICE, device));
    }
    private void scan() {
        if (scanning) return;
        scanning = true;
        scanButton.setText("扫描中，请稍候…");
        scanButton.setEnabled(false);
        info.setText("正在扫描电视局域网，并通过插座 MAC 确认身份…");
        Discovery.search(this, result -> runOnUiThread(() -> {
            scanning = false;
            if (isFinishing() || isDestroyed()) return;
            scanButton.setEnabled(true);
            scanButton.setText("自动扫描设备 IP");
            info.setText(result);
            update();
            new android.app.AlertDialog.Builder(this)
                    .setTitle("SP3 扫描结果")
                    .setMessage(result)
                    .setPositiveButton("确定", null).show();
        }));
    }
}
