package com.tenda.sp3quick;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Google TV remote: left/right chooses plug, OK toggles, Back exits. */
public final class MainActivity extends Activity {
    private DeviceTile light, fan;
    private TextView message;
    private Button refreshButton;
    private boolean refreshing = false;

    private static final class DeviceTile {
        final LinearLayout root;
        final TextView status, action, ip;
        DeviceTile(LinearLayout root, TextView status, TextView action, TextView ip) {
            this.root = root; this.status = status; this.action = action; this.ip = ip;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = TvUi.page(this);
        TextView title = TvUi.text(this, "SP3  智能开关", 34, TvUi.WHITE, true);
        TvUi.add(page, title, this, 52, 3);
        TextView subtitle = TvUi.text(this, "Google TV  ·  局域网控制  ·  遥控器 OK 键操作", 17, TvUi.MUTED, false);
        TvUi.add(page, subtitle, this, 30, 25);

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        light = tile(Devices.LIGHT);
        fan = tile(Devices.FAN);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, TvUi.dp(this, 212), 1);
        lp.rightMargin = TvUi.dp(this, 17);
        cards.addView(light.root, lp);
        cards.addView(fan.root, new LinearLayout.LayoutParams(0, TvUi.dp(this, 212), 1));
        TvUi.add(page, cards, this, 212, 24);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        refreshButton = TvUi.button(this, "↻   刷新两台设备状态", TvUi.PANEL, 62);
        Button settings = TvUi.button(this, "⚙   设备 IP 与设置", TvUi.PANEL, 62);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, TvUi.dp(this, 62), 1);
        p.rightMargin = TvUi.dp(this, 17);
        actions.addView(refreshButton, p);
        actions.addView(settings, new LinearLayout.LayoutParams(0, TvUi.dp(this, 62), 1));
        TvUi.add(page, actions, this, 62, 16);
        message = TvUi.text(this, "← → 选择设备    •    OK 开关    •    返回键退出", 16, TvUi.MUTED, false);
        TvUi.add(page, message, this, 34, 0);

        refreshButton.setOnClickListener(v -> refresh(true));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        // D-pad focus is explicit between the two most important actions.
        light.root.setId(View.generateViewId()); fan.root.setId(View.generateViewId());
        refreshButton.setId(View.generateViewId()); settings.setId(View.generateViewId());
        light.root.setNextFocusRightId(fan.root.getId());
        fan.root.setNextFocusLeftId(light.root.getId());
        light.root.setNextFocusDownId(refreshButton.getId());
        fan.root.setNextFocusDownId(settings.getId());
        refreshButton.setNextFocusUpId(light.root.getId());
        settings.setNextFocusUpId(fan.root.getId());
        light.root.requestFocus();
        render();
    }

    private DeviceTile tile(String device) {
        boolean isLight = Devices.LIGHT.equals(device);
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(TvUi.dp(this, 30), TvUi.dp(this, 20), TvUi.dp(this, 28), TvUi.dp(this, 20));
        TextView name = TvUi.text(this, isLight ? "●  电灯" : "◉  电风扇", 30, TvUi.WHITE, true);
        TvUi.add(tile, name, this, 46, 8);
        TextView status = TvUi.text(this, "未检测", 24, TvUi.WHITE, true);
        TvUi.add(tile, status, this, 43, 4);
        TextView action = TvUi.text(this, "OK 读取状态并切换", 18, TvUi.MUTED, false);
        TvUi.add(tile, action, this, 35, 7);
        TextView ip = TvUi.text(this, Devices.ip(this, device), 16, TvUi.MUTED, false);
        TvUi.add(tile, ip, this, 30, 0);
        TvUi.focusStyle(this, tile, TvUi.PANEL);
        tile.setContentDescription(Devices.name(device) + "开关");
        tile.setOnClickListener(v -> {
            if (Devices.status(this, device) == Devices.PENDING) return;
            toggle(device);
        });
        return new DeviceTile(tile, status, action, ip);
    }

    @Override protected void onResume() {
        super.onResume();
        render();
        refresh(false);
    }

    private void toggle(String device) {
        message.setText("正在控制" + Devices.name(device) + "…");
        Controller.toggle(this, device, (ok, text) -> runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            render();
            message.setText(ok ? text : Devices.name(device) + "：" + text);
            if (!ok) Toast.makeText(this, text, Toast.LENGTH_LONG).show();
        }));
        render();
    }

    private void refresh(boolean manual) {
        if (refreshing) return;
        refreshing = true;
        refreshButton.setEnabled(false);
        message.setText("正在读取两台 SP3 的实际状态…");
        Controller.refresh(this, Devices.LIGHT, (ok1, text1) -> runOnUiThread(() -> {
            if (!isFinishing() && !isDestroyed()) render();
            Controller.refresh(this, Devices.FAN, (ok2, text2) -> runOnUiThread(() -> {
                refreshing = false;
                if (isFinishing() || isDestroyed()) return;
                refreshButton.setEnabled(true);
                render();
                if (ok1 && ok2) message.setText("状态已更新   ·   ← → 选择设备，OK 键切换");
                else {
                    String detail = (!ok1 ? "电灯：" + text1 + "   " : "") + (!ok2 ? "风扇：" + text2 : "");
                    message.setText(detail);
                    if (manual) Toast.makeText(this, detail, Toast.LENGTH_LONG).show();
                }
            }));
        }));
    }

    private void render() {
        renderOne(Devices.LIGHT, light);
        renderOne(Devices.FAN, fan);
    }
    private void renderOne(String device, DeviceTile tile) {
        if (tile == null) return;
        int status = Devices.status(this, device);
        int color;
        String label;
        String action;
        if (status == 1) { color = TvUi.GREEN; label = "已开启"; action = "按 OK 关闭"; }
        else if (status == 0) { color = TvUi.RED; label = "已关闭"; action = "按 OK 开启"; }
        else if (status == Devices.PENDING) { color = TvUi.AMBER; label = "切换中…"; action = "正在等待设备确认"; }
        else { color = TvUi.PANEL; label = "未连接 / 未知"; action = "按 OK 尝试连接并切换"; }
        TvUi.focusStyle(this, tile.root, color);
        tile.status.setText(label);
        tile.action.setText(action);
        tile.ip.setText("IP  " + Devices.ip(this, device));
        // Keep selected tile focus even when its appearance changes.
    }
}
