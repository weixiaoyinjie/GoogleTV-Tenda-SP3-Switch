package com.tenda.sp3quick;

import android.content.Context;
import android.net.Network;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** User-triggered /24 scan through the TV's Ethernet or Wi-Fi, never background. */
final class Discovery {
    interface Done { void complete(String message); }
    private static final class Found {
        final String ip, mac;
        Found(String ip, String mac) { this.ip = ip; this.mac = mac; }
    }
    static void search(Context context, Done done) {
        Context app = context.getApplicationContext();
        new Thread(() -> {
            String message;
            try {
                Network wifi = NetworkRouter.local(app);
                String prefix = NetworkRouter.prefix(app, wifi);
                ExecutorService pool = Executors.newFixedThreadPool(16);
                CompletionService<Found> queue = new ExecutorCompletionService<>(pool);
                try {
                    for (int i = 1; i <= 254; i++) {
                        final String address = prefix + i;
                        queue.submit(() -> {
                            try {
                                String mac = PlugClient.getMacFast(address, wifi);
                                return mac == null || mac.isEmpty() ? null : new Found(address, mac);
                            } catch (Exception ignored) { return null; }
                        });
                    }
                    Map<String, String> found = new HashMap<>();
                    for (int i = 1; i <= 254; i++) {
                        Future<Found> future = queue.poll(22, TimeUnit.SECONDS);
                        if (future == null) break;
                        Found hit = future.get();
                        if (hit == null) continue;
                        String normalized = hit.mac.replace(":", "").replace("-", "");
                        for (String device : new String[] {Devices.LIGHT, Devices.FAN}) {
                            if (normalized.equalsIgnoreCase(Devices.mac(device).replace(":", ""))) {
                                found.put(device, hit.ip);
                            }
                        }
                        if (found.size() == 2) break;
                    }
                    for (Map.Entry<String, String> entry : found.entrySet()) {
                        Devices.setIp(app, entry.getKey(), entry.getValue());
                    }
                    Devices.resetState(app);
                    message = found.isEmpty() ? "未找到目标插座。请检查电视与插座是否在可互通的家庭局域网，或手动填写 IP。" :
                            "找到" + found.size() + "台：" +
                            (found.containsKey(Devices.LIGHT) ? " 电灯 " + found.get(Devices.LIGHT) : "") +
                            (found.containsKey(Devices.FAN) ? " 风扇 " + found.get(Devices.FAN) : "");
                } finally { pool.shutdownNow(); }
            } catch (Exception e) {
                message = "扫描失败：" + (e.getMessage() == null ? "Wi-Fi 无法访问" : e.getMessage());
            }
            done.complete(message);
        }, "tv-sp3-discovery").start();
    }
}
