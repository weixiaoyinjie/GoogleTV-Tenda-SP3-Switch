package com.tenda.sp3quick;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** D-pad-friendly numeric IP editor without requiring a Bluetooth keyboard or TV IME. */
public final class IpEditActivity extends Activity {
    static final String KEY_DEVICE = "device";
    private String device;
    private final StringBuilder value = new StringBuilder();
    private TextView display, help;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        device = getIntent() == null ? null : getIntent().getStringExtra(KEY_DEVICE);
        if (!Devices.LIGHT.equals(device) && !Devices.FAN.equals(device)) { finish(); return; }
        value.append(Devices.ip(this, device));
        LinearLayout page = TvUi.page(this);
        TvUi.add(page, TvUi.text(this, "修改" + Devices.name(device) + "的 IP", 32, TvUi.WHITE, true), this, 50, 8);
        TvUi.add(page, TvUi.text(this, "使用方向键移动，按 OK 输入数字", 16, TvUi.MUTED, false), this, 28, 12);

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.HORIZONTAL);
        center.setGravity(Gravity.CENTER_VERTICAL);
        display = TvUi.text(this, value.toString(), 29, TvUi.WHITE, true);
        display.setGravity(Gravity.CENTER);
        display.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        display.setBackground(TvUi.bg(this, TvUi.PANEL, TvUi.FOCUS));
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, TvUi.dp(this, 125), 1);
        dp.rightMargin = TvUi.dp(this, 20);
        center.addView(display, dp);
        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        String[][] grid = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {".", "0", "⌫"}};
        Button firstKey = null;
        for (String[] keys : grid) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = 0; i < keys.length; i++) {
                String key = keys[i];
                Button b = TvUi.button(this, key, TvUi.PANEL, 53);
                b.setTextSize(23);
                LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(0, TvUi.dp(this, 53), 1);
                if (i != 0) kp.leftMargin = TvUi.dp(this, 8);
                row.addView(b, kp);
                b.setOnClickListener(v -> key(key));
                if (firstKey == null) firstKey = b;
            }
            TvUi.add(pad, row, this, 53, 8);
        }
        center.addView(pad, new LinearLayout.LayoutParams(0, -2, 1));
        TvUi.add(page, center, this, -1, 12);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        Button clear = TvUi.button(this, "清空", TvUi.RED, 55);
        Button save = TvUi.button(this, "保存 IP", TvUi.GREEN, 55);
        Button cancel = TvUi.button(this, "取消 / 返回", TvUi.PANEL, 55);
        Button[] buttons = {clear, save, cancel};
        for (int i = 0; i < buttons.length; i++) {
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, TvUi.dp(this, 55), 1);
            if (i > 0) bp.leftMargin = TvUi.dp(this, 10);
            bottom.addView(buttons[i], bp);
        }
        TvUi.add(page, bottom, this, 55, 8);
        help = TvUi.text(this, "仅允许家庭局域网 IP；例如 192.168.0.30", 16, TvUi.MUTED, false);
        TvUi.add(page, help, this, 40, 0);
        clear.setOnClickListener(v -> { value.setLength(0); render(); });
        save.setOnClickListener(v -> save());
        cancel.setOnClickListener(v -> finish());
        if (firstKey != null) firstKey.requestFocus();
    }

    private void key(String v) {
        if ("⌫".equals(v)) {
            if (value.length() > 0) value.deleteCharAt(value.length() - 1);
        } else if (".".equals(v)) {
            if (value.length() > 0 && value.charAt(value.length() - 1) != '.' && dots() < 3) value.append('.');
        } else if (value.length() < 15) {
            value.append(v);
        }
        render();
    }
    private int dots() {
        int result = 0;
        for (int i = 0; i < value.length(); i++) if (value.charAt(i) == '.') result++;
        return result;
    }
    private void render() {
        display.setText(value.length() == 0 ? "—" : value.toString());
        help.setText("方向键选择数字 · OK 输入 · 保存前校验 IP");
    }
    private void save() {
        String ip = value.toString();
        if (!Devices.validIp(ip)) {
            help.setText("IP 不合法，请输入家庭局域网 IPv4 地址");
            Toast.makeText(this, "IP 格式不合法", Toast.LENGTH_SHORT).show();
            return;
        }
        String other = Devices.LIGHT.equals(device) ? Devices.FAN : Devices.LIGHT;
        if (ip.equals(Devices.ip(this, other))) {
            help.setText("两台设备不能使用相同 IP");
            return;
        }
        Devices.setIp(this, device, ip);
        Devices.resetState(this);
        Toast.makeText(this, Devices.name(device) + " IP 已保存", Toast.LENGTH_SHORT).show();
        finish();
    }
}
