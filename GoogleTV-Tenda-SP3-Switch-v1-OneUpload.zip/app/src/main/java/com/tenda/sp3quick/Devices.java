package com.tenda.sp3quick;

import android.content.Context;
import android.content.SharedPreferences;

/** Same two physical SP3 devices and remembered IPs as phone v1.2. */
final class Devices {
    static final String LIGHT = "light";
    static final String FAN = "fan";
    static final int UNKNOWN = -1;
    static final int PENDING = -2;

    static String name(String device) { return LIGHT.equals(device) ? "电灯" : "电风扇"; }
    static String defaultIp(String device) { return LIGHT.equals(device) ? "192.168.0.30" : "192.168.0.31"; }
    static String mac(String device) { return LIGHT.equals(device) ? "D8:32:14:65:62:B8" : "D8:32:14:65:63:6C"; }

    private static SharedPreferences pref(Context c) {
        return c.getApplicationContext().getSharedPreferences("plugs", Context.MODE_PRIVATE);
    }
    static String ip(Context c, String device) { return pref(c).getString(device + "_ip", defaultIp(device)); }
    static void setIp(Context c, String device, String ip) { pref(c).edit().putString(device + "_ip", ip).apply(); }
    static int status(Context c, String device) { return pref(c).getInt(device + "_status", UNKNOWN); }
    static void setStatus(Context c, String device, int state) { pref(c).edit().putInt(device + "_status", state).apply(); }
    static String error(Context c, String device) { return pref(c).getString(device + "_error", ""); }
    static void setError(Context c, String device, String value) { pref(c).edit().putString(device + "_error", value).apply(); }
    static boolean verifyMac(Context c) { return pref(c).getBoolean("verify_mac", true); }
    static void setVerifyMac(Context c, boolean enabled) { pref(c).edit().putBoolean("verify_mac", enabled).apply(); }

    static void resetState(Context c) {
        for (String d : new String[] {LIGHT, FAN}) {
            setStatus(c, d, UNKNOWN);
            setError(c, d, "");
        }
    }

    static boolean validIp(String ip) {
        if (ip == null) return false;
        String[] parts = ip.split("\\.", -1);
        if (parts.length != 4) return false;
        int[] n = new int[4];
        for (int i = 0; i < 4; i++) {
            if (parts[i].isEmpty() || parts[i].length() > 3 || !parts[i].matches("[0-9]+")) return false;
            try { n[i] = Integer.parseInt(parts[i]); }
            catch (NumberFormatException e) { return false; }
            if (n[i] > 255) return false;
        }
        // Restrict commands to RFC1918 private addresses to prevent accidental public requests.
        return n[0] == 10 || (n[0] == 172 && n[1] >= 16 && n[1] <= 31) || (n[0] == 192 && n[1] == 168);
    }
}
